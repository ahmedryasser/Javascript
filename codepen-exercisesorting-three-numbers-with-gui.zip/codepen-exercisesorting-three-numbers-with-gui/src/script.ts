/*
    Name: Ahmed Najiub
    URL: https://codepen.io/ahmedryasser/pen/wvvvWOR
*/

$("#go").click(() => {
  let a = Number($("#a").val());
  let b = Number($("#b").val());
  let c = Number($("#c").val());
  
  if (a > b ){
    if (b > c){
      let order= [c, b, a];

    }
    else if (a>c){
      let order=  [b, c, a];
    }
    else {
      let order=  [b, a, c];
    }
  } 
  else {
    if (a>c){
      let order=  [c, a, b];
    }
    else if (b>c){
      let order= [a, c, b];
    }
    else {
      let order= [a, b, c];
    }
  }
    $("#out").html(order);
});

