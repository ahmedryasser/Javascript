function square(n:number): string{
  let s = "";
  for (let i=1;i<=n;i++){
    for (let j=1;j<=i;j++){
      s += "@ ";
    }
    s += "<br>";
  }
  return s;
}
$("#goButton").click(() => {
  let num = $("input").val();
  let output = square(num);
  $("#out").html(output);
});