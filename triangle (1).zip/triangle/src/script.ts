function hyp(sideA: number, sideB: number): number{
  let sum = Math.pow(sideA, 2) + MAth.pow(sideB, 2);
  return Math.sqrt(sideA + sideB);
}
let h = hyp(3,4)
console.log(h);