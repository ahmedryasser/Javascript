/*
Name: Ahmed Najiub
URL: https://codepen.io/ahmedryasser/pen/pooxRWR?editors=0010
*/
function rectangleWithBorder(rows: number, cols: number, border: number): string {
  let str = "";
  for (let i = 1; i <= rows; i++) {
    for (let j = 1; j <= cols; j++) {
      if (j <= border || j > (cols - border) || i <= border || i > (rows - border)) {
        str += " o ";
      } 
      else {
        str += " x ";
      }
    }
    str += "<br>";
  }
  return str;
}

$("#goButton").click(() => {
  let num1 = Number($("#rowsInput").val());
  let num2 = Number($("#colsInput").val());
  let num3 = Number($("#borderInput").val());
  let output = rectangleWithBorder(num1, num2, num3);
  if (num1 <= 0 ||num2 <= 0 ||  num3 < 0) {
    $("#out").html("Invalid");
  } 
  else {
    $("#out").html(output);
  }
});