function numberMatrix(str: string): number[][] {
  let m = [];
  let rows = str.split(/\n/);
  for (let i = 0; i < rows.length; i++) {
    m[i] = [];
    let cols = rows[i].split(/\s+/);
    for (let j = 0; j < cols.length; j++) {
      m[i][j] = Number(cols[j]);
    }
  }
  return m;
}

function maxMatrix(m: number[][]): number {
  let largest = m[0][0];
  for (let i = 0; i < m.length; i++) {
    for (let j = 0; j < m[i].length; j++) {
      if (m[i][j] > largest) {
        largest = m[i][j];
      }
    }
  }
  return largest;
}

$("#go").click(() => {
  let x = numberMatrix($("#in").val());
  let max = maxMatrix(x);
  $("#out").html("<h1>The largest value is " + max + "</h1>");
})

// console.log(numberMatrix("2  4  6\n8 5  3"));