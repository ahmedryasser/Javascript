/*
  Name: Ahmed Najiub
  URL: https://codepen.io/ahmedryasser/pen/yLLMOQv?editors=0011
*/

function dec2hex(dec: number): string {
  let hexString = "";
  while (dec > 0) {
    let num = dec % 16;
    num = num.toFixed(0);
    if (num == 10) {
      num = "A";
    } 
    else if (num == 11) {
      num = "B";
    } 
    else if (num == 12) {
      num = "C";
    } 
    else if (num == 13) {
      num = "D"; 
    } 
    else if (num == 14) {
      num = "E";
    } 
    else if (num == 15){
      num = "F";
    } 
    hexString = num + hexString;
    dec = Math.floor(dec / 16);
  }
  return hexString;
}

$("#goButton").click( () => {
  let decVal = $("#decimalInput").val();
  if(decVal >= 0) {
    $("#out").html("HEX value => " + dec2hex(decVal));
  } 
  else {
   $("#out").html("Input is invalid");
  }
}

// console.log("dec2hex(42) == " + dec2hex(42));       // A: 2A
// console.log("dec2hex(596) == " + dec2hex(596));     // A: 254
// console.log("dec2hex(801) == " + dec2hex(801);      // A: 321
// console.log("dec2hex(1801) == " + dec2hex(1801));   // A: 709
// console.log("dec2hex(1819) == " + dec2hex(1819));   // A: 71B
// console.log("dec2hex(175) == " + dec2hex(175));     // A: AF
// console.log("dec2hex(475) == " + dec2hex(475));     // A: 1DB
// console.log("dec2hex(12793) == " + dec2hex(12793)); // A: 31F9
// console.log("dec2hex(0) == " + dec2hex(0));         // A: 0
// console.log("dec2hex(255) == " + dec2hex(255));     // A: FF
