/*
    Name: Ahmed Najiub
    URL: https://codepen.io/ahmedryasser/pen/NWWbwYJ?editors=0010
*/
function ddb(cost:number, n:number, k:number): number{
  $("#out").html(" ");
  let i =1;
  while(n>=i && k!=0){
    cost = cost-((2/n)*cost);
    if (i==k){
      return cost;
    }
    i++;
  }
  return cost;
}

$("#goButton").click(() => {
  ddb.cost = Number($("#costInput").val());;
  ddb.n = Number($("#lifeInput").val());;
  ddb.k = Number($("#yearInput").val());;
  $("#out").append(ddb(ddb.cost, ddb.n, ddb.k) + " ");
});

// Test code--do not change

console.log("ddb(1000, 5, 0) == " + ddb(1000, 5, 0)); // A: 1000
console.log("ddb(1000, 5, 1) == " + ddb(1000, 5, 1)); // A: 600
console.log("ddb(1000, 5, 2) == " + ddb(1000, 5, 2)); // A: 360
console.log("ddb(1000, 5, 3) == " + ddb(1000, 5, 3)); // A: 216
console.log("ddb(1000, 5, 4) == " + ddb(1000, 5, 4)); // A: 129.6
console.log("ddb(1000, 5, 5) == " + ddb(1000, 5, 5)); // A: 77.75999999999999
console.log("ddb(8500, 7, 3) == " + ddb(8500, 7, 3)); // A: 3097.6676384839648