/*
    Name: Ahmed Najiub
    URL: https://codepen.io/ahmedryasser/pen/XWrELbz?editors=0110
*/
const LOW_RATE = 0.05;
const HIGH_RATE = 0.15;
const THRESHOLD = 1000;
function commission(sales:number ): number{
 
  if (sales>=10000){
    return (Math.floor((sales-1000)*HIGH_RATE));
  }
  else if (sales>THRESHOLD && sales < 10000){
    return (Math.floor((sales-1000)*LOW_RATE));
  }
  else{
    return 0;
  }
}


// Test code--do not change

console.log("commission(3000) => ", commission(3000));   // should print 100
console.log("commission(11000) => ", commission(11000)); // should print 1500
console.log("commission(10000) => ", commission(10000)); // should print 1350
console.log("commission(500) => ", commission(500));     // should print 0
console.log("commission(5300) => ", commission(5300));   // should print 215
console.log("commission(20000) => ", commission(20000)); // should print 2850