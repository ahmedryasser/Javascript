/*
Name: Ahmed Najiub
URL: https://codepen.io/ahmedryasser/pen/WNNOoWx?editors=0010
*/
function euler(n:number): number{
  let i=1;
  let num=1;
  let num2=1;
  while(i<n){
    num = num*(1/i);
    num2 = num2 + num;
    i++;
  }
  return num2;
}

$("#goButton").click (() => {
  inNum=$("#numInput").val();
  let output = euler(inNum);
  $("#out").html(output);
});