$("#go").click(() => {
  let n = Number($("#n").val());
  const COL_WIDTH = 6;
  if (n < 1) {
    $("#out").html("<h1>Invalid n for multiplication table");
  } else {
    $("#out").html("&nbsp;".repeat(COL_WIDTH));
    for (let i = 1; i <= n; i++) {
      let num = i.toString();
      $("#out").append("&nbsp;".repeat(COL_WIDTH - num.length);
      $("#out").append("<strong>" + num + "<strong>");
    }
    $("#out").append("<br>");
    for (let i=1; i<=n; i++){
      let num = i.toString();
      $("#out").append("&nbsp;".repeat(COL_WIDTH - num.length));
      $("#out").append("<strong>" + num + "<strong>");      
      for (let j=1; j<=n; j++){
        let num= (i*j).toString();
        $("#out").append("&nbsp;".repeat(COL_WIDTH - num.length));
        $("#out").append(num);  
      }
     $("#out").append("<br>");
     
    }
  }
});