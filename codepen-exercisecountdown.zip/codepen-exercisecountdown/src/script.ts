/*
    Name: Ahmed Najiub
    URL: https://codepen.io/ahmedryasser/pen/BaaLYOY?editors=1010
*/
function countdown() {
  $("#out").html(countdown.n);
  $("#out").css("color", "rgb(255," + 255/(countdown.n) + ", 0)");
  (countdown.n)--;
  if (countdown.n == -2) {
    clearInterval(countdown.timer);
    $("#out").html("BOOOOM!");
    $("#out").css("backgroundColor", "yellow");
    $("#out").css("color", "black");
   } 
  else {
    $("#out").css("backgroundColor", "black");
   }
}

$("#goButton").click(() => {
  countdown.n = Number($("#numInput").val());
  countdown.timer = setInterval(countdown, 500);
});