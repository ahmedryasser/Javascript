function dec2bin(dec: number): string {
  let binStr = "";
  while (dec > 0) {
    let bit = dec % 2;
    bit = bit.toFixed(0);
    binStr = bit + binStr;
    dec = Math.floor(dec / 2);
  }
  return binStr;
}
console.log(dec2bin(37));