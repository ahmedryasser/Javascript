let x = (Math.floor(100*(Math.random(1, 10))));
function temp(x:number): string{
  if (x<=80){
    return "sunny";
  }
  else if (x< 95){
    return "foggy";
  }
  else if (x< 99) {
    return "rainy";
  }
  else {
    return on "fire";
  }

console.log(temp(x));