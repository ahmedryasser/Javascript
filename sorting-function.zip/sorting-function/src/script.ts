function inOrder (a: number, b: number, c:number): number[]{
  if (a > b ){
    if (b > c){
      return [a, b, c];

    }
    else if (a>c){
      return [a, c, b];
    }
    else {
      return [c, a, b];
    }
  } 
  else {
    if (a>c){
      return [b, a, c];
    }
    else if (b>c){
      return[b, c, a];
    }
    else {
      return[c, b, a];
    }
  }
    
    
  

}
console.log(inOrder(7, 5, 8));