/*
    Name: Ahmed Najiub
    URL: https://codepen.io/ahmedryasser/pen/bGbjWev?editors=0012
*/

function deansList(numA: number, numB: number, numC: number, numD: number, numF: number): string[] {
  let ogNum = (numA+numB+numC+numD+numF); 
  
  function average(numbA: number, numbB: number, numbC: number, numbD: number, numbF: number){
  if (ogNum==4){
    let avg1 = (numbA+numbB+numbC+numbD+numbF)/4;
    return avg1;
  }
  else{
    let avg2 = (numbA+numbB+numbC+numbD+numbF)/5;
    return avg2;
  }
}
  
  numA = numA*4;
  numB = numB*3;
  numC = numC*2;
  numF = 0;
  
  
  let avg = average(numA, numB, numC, numD, numF).toFixed(1);
  if (avg >= 3.5){
    return [ avg, "Dean\'s list'"];
  }
  else if (avg >= 2){
    return [avg, "Satisfactory"];
  }
  else{
    return [avg, "Unsatisfactory"];
  }
}

// Test code--do not change

console.log("deansList(2, 1, 1, 0, 1) => ", deansList(2, 1, 1, 0, 1)); // should print [ '2.6', 'Satisfactory' ]
console.log("deansList(4, 0, 0, 0, 0) => ", deansList(4, 0, 0, 0, 0)); // should print [ '4.0', 'Dean\'s list' ]
console.log("deansList(2, 2, 0, 0, 0) => ", deansList(2, 2, 0, 0, 0)); // should print [ '3.5', 'Dean\'s list' ]
console.log("deansList(2, 2, 1, 0, 0) => ", deansList(2, 2, 1, 0, 0)); // should print [ '3.2', 'Satisfactory' ]
console.log("deansList(0, 0, 5, 0, 0) => ", deansList(0, 0, 5, 0, 0)); // should print [ '2.0', 'Satisfactory' ]
console.log("deansList(0, 0, 4, 1, 0) => ", deansList(0, 0, 4, 1, 0)); // should print [ '1.8', 'Unsatisfactory' ]
