function change(amount: number): number[] {
  let quarters = Math.floor(amount / 25);
  amount = amount % 25;
  let dimes = Math.floor(amount / 10);
  amount = amount % 10;  
  let nickels = Math.floor(amount / 5);
  let pennies = amount % 5; 
  return [quarters, dimes, nickels, pennies];
}

console.log(change(39));