/*
Name: Ahmed Najiub
URL: https://codepen.io/ahmedryasser/pen/oNNwoRX?editors=0010
*/
function numberArray(str: string): number[] {
  let numArray = str.split(/\s+/);
  let i = 0;
  while (i < numArray.length) {
    numArray[i] = Number(numArray[i]);
    i++;
  } 
  return numArray;
}
function sumEven(v: number[]): number{
  let i = 0;
  let sum = 0;
  let vLen= v.length;
  while (i<vLen){
    if ((v[i])%2==0){
      sum += Number(v[i]); 
    }
    i++;
  }
  return sum;
}

$("#goButton").click (() => {
  num=$("#listInput").val();
  let output = sumEven(numberArray(num));
  $("#out").html("The sum of even integers is " + output);
});

console.log("sumEven([]) == " + sumEven([]));                                     // A: 0
console.log("sumEven([42]) == " + sumEven([42]));                                 // A: 42
console.log("sumEven([43]) == " + sumEven([43]));                                 // A: 0
console.log("sumEven([1, 2, 3]) == " + sumEven([1, 2, 3]));                       // A: 2
console.log("sumEven([4, 6, 8, 10]) == " + sumEven([4, 6, 8, 10]));               // A: 28
console.log("sumEven([4, 6, 8, 9]) == " + sumEven([4, 6, 8, 9]));                 // A: 18
console.log("sumEven([3, 4, 6, 8]) == " + sumEven([3, 4, 6, 8]));                 // A: 18
console.log("sumEven([-2, 8, 5, 6, -4, 6]) == " + sumEven([-2, 8, 5, 6, -4, 6])); // A: 14
console.log("sumEven([-2, 0, 2]) == " + sumEven([-2, 0, 2]));                     // A: 0
console.log("sumEven([-5, -3, 3, 4]) == " + sumEven([-5, -3, 3, 4]));             // A: 4
