function oct2dec(x:string): number{
  let len = x.length;
  let sum  = 0;
  let power = 1;
  for (let i=0;i<len;i++){
    let position = x.charAt(len-i-1);
    sum += position*power
    power*=8;
  }
  return sum;
}
$("#button").click(()=> {
  let num= $("#input").val();
  let output = oct2dec(num);
  $("#out").html(output);
});
