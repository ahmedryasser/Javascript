/*
    Name: Ahmed Najiub
    URL: https://codepen.io/ahmedryasser/pen/QWLrJqK?editors=0012
*/
const SMALL_PRIZE = 10;
const LARGE_PRIZE = 75;
const THRESHOLD = 200;

function average(num1: number, num2: number, num3: number){
  avg = (num1+num2+num3)/3;
  return avg;
}
function prize(score1: number, score2: number, score3: number): number{
  if (average(score1, score2, score3) >= THRESHOLD){
    return LARGE_PRIZE;
  }
  else{
    return SMALL_PRIZE;
  }
}


// Test code--do not change

console.log("prize(250, 200, 220) => ", prize(250, 200, 220)); // should print 75
console.log("prize(150, 210, 175) => ", prize(150, 210, 175)); // should print 10
console.log("prize(200, 200, 200) => ", prize(200, 200, 200)); // should print 75
console.log("prize(100, 100, 100) => ", prize(100, 100, 100)); // should print 10
console.log("prize(150, 250, 210) => ", prize(150, 250, 210)); // should print 75
console.log("prize(200, 250, 300) => ", prize(200, 250, 300)); // should print 75
