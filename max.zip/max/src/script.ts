function numberArray(str: string): number[] {
  let numArray = str.split(/\s+/);
  let i = 0;
  while (i < numArray.length) {
    numArray[i] = Number(numArray[i]);
    i++;
  } 
  return numArray;
}

function max(v: number[]): number {
  let largest = v[0];
  let i = 1;
  while (i < v.length) {
    if (v[i] > largest) {
      largest = v[i];
    }
    i++;
  }
  return largest;
}

$("#go").click(() => {
  let nums = numberArray($("#numbers").val());
  let m = max(nums);
  $("#out").html("<h1>The largest value is " + m + "</h1>");
});