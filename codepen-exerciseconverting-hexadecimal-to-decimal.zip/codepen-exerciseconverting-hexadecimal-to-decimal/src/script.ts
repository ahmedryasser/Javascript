//Name: Ahmed Najiub
//URL: https://codepen.io/ahmedryasser/pen/QWWpKYj?editors=0110

function hex2dec (hex:string): number{
  let len = hex.length;
  let sum = 0;
  let i = 0;
  let power = 1;
  while (i<len) {
    let position = hex.charAt(len-1-i);
    if (position == "A" || position == "a") 
      {position = 10;}
    else if (position == "B" || position == "b")
      {position = 11;} 
    else if (position == "C"|| position == "c") 
      {position = 12;} 
    else if (position == "D"|| position == "d") 
      {position = 13;} 
    else if (position == "E"|| position == "e") 
      {position = 14;}
    else if (position == "F"|| position == "f") 
      {position = 15;}
    else 
      {position;}
    
    sum = sum+power*position;
    power *= 16;
    i++;
  }
  return sum;
}

$("#goButton").click(() => {
  let hexInput = $("#hexInput").val();
  let d = hex2dec(hexInput);
  $("#out").html( "DEC value => " +d); 
});

//console.log("hex2dec(\"2A\") == " + hex2dec("2A"));     // A: 42
// console.log("hex2dec(\"254\") == " + hex2dec("254"));   // A: 596
// console.log("hex2dec(\"321\") == " + hex2dec("321");    // A: 801
// console.log("hex2dec(\"709\") == " + hex2dec("709"));   // A: 1801
// console.log("hex2dec(\"71B\") == " + hex2dec("71B"));   // A: 1819
// console.log("hex2dec(\"AF\") == " + hex2dec("AF"));     // A: 175
// console.log("hex2dec(\"1DB\") == " + hex2dec("1DB"));   // A: 475
// console.log("hex2dec(\"31F9\") == " + hex2dec("31F9")); // A: 12793
// console.log("hex2dec(\"0\") == " + hex2dec("0"));       // A: 0
// console.log("hex2dec(\"FF\") == " + hex2dec("FF"));     // A: 255
