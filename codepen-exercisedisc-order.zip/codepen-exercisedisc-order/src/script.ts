/*
    Name: Ahmed Najiub
    URL: https://codepen.io/ahmedryasser/pen/KKPGpKX?editors=0010
*/

function discOrder(quantity: number): number{
  if(quantity <= 99){
    return (quantity*10)+(quantity*10)*0.09;
  }
  else if(quantity <= 199){
    return (quantity*9)+(quantity*9)*0.09;
  }
  else if(quantity <= 299){
    return (quantity*7.5)+(quantity*7.5)*0.09;
  } 
  else{
    return (quantity*5)+(quantity*5)*0.09;
  }
}

// Test code--do not change

console.log("discOrder(75) => ", discOrder(75));   // should print 817.5 
console.log("discOrder(99) => ", discOrder(99));   // should print 1079.1
console.log("discOrder(100) => ", discOrder(100)); // should print 981
console.log("discOrder(150) => ", discOrder(150)); // should print 1471.5
console.log("discOrder(250) => ", discOrder(250)); // should print 2043.75
console.log("discOrder(299) => ", discOrder(299)); // should print 2444.325
console.log("discOrder(360) => ", discOrder(360)); // should print 1962

// Note: due to round-off error, may print values such as 817.5000000000001