/*
    Name: Ahmed Najiub
    URL: https://codepen.io/ahmedryasser/pen/QWLobpw
*/
function stripTitle(name: string): string{
  if(name.includes("Prof")){
    let noLetters = name.indexOf('.');
    return name.slice(noLetters+1);
  } 
  else if(name.includes("Dr")){
    let noLetters = name.indexOf('.');
    return name.slice(noLetters+1);
  }  
  else if(name.includes("Rev")){
    let noLetters = name.indexOf('.');
    return name.slice(noLetters+1); 
  }
  else{
    return name;
  }
}


// Test code--do not change

console.log("stripTitle(\"Dr. Stan Warford\") => " + stripTitle("Dr. Stan Warford"));
    // should print Stan Warford
console.log("stripTitle(\"Dr. Susan Helm\") => " + stripTitle("Dr. Susan Helm"));  
    // should print Susan Helm
console.log("stripTitle(\"Prof. Jennifer Lawrence\") => " + stripTitle("Prof. Jennifer Lawrence"));  
    // should print Jennifer Lawrence
console.log("stripTitle(\"Rev. Jesse Jackson\") => " + stripTitle("Rev. Jesse Jackson"));  
    // should print Jesse Jackson
console.log("stripTitle(\"Rev. Bea Arthur\") => " + stripTitle("Rev. Bea Arthur"));
    // should print Bea Arthur
console.log("stripTitle(\"Brad Pitt\") => " + stripTitle("Brad Pitt"));
    // should print Brad Pitt
console.log("stripTitle(\"Sgt. Milli Vanilli\") => " + stripTitle("Sgt. Milli Vanilli"));
    // should print Sgt. Milli Vanilli
