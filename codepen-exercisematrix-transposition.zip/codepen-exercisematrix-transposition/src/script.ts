/*
Name: Ahmed Najiub
URL: https://codepen.io/ahmedryasser/pen/eYYwYZr?editors=1010
*/
function numberMatrix(str: string): number[][] {
  let m = [];
  let rows = str.split(/\n/);
  for (let i = 0; i < rows.length; i++) {
    m[i] = [];
    let cols = rows[i].split(/\s+/);
    for (let j = 0; j < cols.length; j++) {
      m[i][j] = Number(cols[j]);
    }
  }
  return m;
}

function transpose(x: number[][]): number[][]{
  let z=[];
  for (let i = 0; i < x[0].length; i++) {
    z[i]= [];
    for (let j = 0; j < x.length; j++) {
      console.log(x[j][i]);
      z[i][j] = x[j][i]; 
      }
    }
  return z;
}
function displayMatrix(m: number[][], widget: object): void{
  widget.html("<br>");
  for (let i = 0; i<m.length;i++){
    widget.append(m[i] +"<br>")
  }
}

$("#goButton").click(() => {
  let mat = numberMatrix($("#matrixInput").val());
  let c = transpose(mat);
  console.log(c);
  displayMatrix(c, $("#out"));
});