/*
    Name: Ahmed Najiub
    URL: https://codepen.io/ahmedryasser/pen/JjPpBmP?editors=0010
*/
function operations(x:number, y:number): number[]{
  let add = x+y;
  let sub = x-y;
  let mult = x*y;
  let div1 = x/y;
  let div2 = Math.floor(div1);
  let rem = x%y;
  return [add, sub, mult, div1, div2, rem];
 }


// Test code--do not change

console.log("operations(15, 2) => ", operations(15, 2));   // should print [17, 13, 30, 7.5, 7, 1]
console.log("operations(81, 4) => ", operations(81, 4));   // should print [85, 77, 324, 20.25, 20, 1]
console.log("operations(4, 5) => ", operations(4, 5));     // should print [9, -1, 20, 0.8, 0, 4]
console.log("operations(35, 5) => ", operations(35, 5));   // should print [40, 30, 175, 7, 7, 0]
console.log("operations(73, 4) => ", operations(73, 4));   // should print [77, 69, 292, 18.25, 18, 1]
