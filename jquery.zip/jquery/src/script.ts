$("#go").click(() => {
  let hours = Number($("#hours").val());
  let rate = Number($("#rate").val());
  if (hours<=40){
    let wages = hours*rate;
    $("#out").css("backgroundColor", "green")
  }
  else{
    let wages = (40*rate) + rate*(hours-40)*1.5;
    $("#out").css("backgroundColor", "yellow")    
  }
  console.log( wages);
  $("#out").html(wages);
});

