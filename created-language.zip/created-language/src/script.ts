function pig(ogWord: string){
  let a = ogWord.indexOf('a');
  let o = ogWord.indexOf('o');
  let u = ogWord.indexOf('u');
  let i = ogWord.indexOf('i');
  let e = ogWord.indexOf('e');
  if(a==-1) a=999;
  if(o==-1) o=999;
  if(u==-1) u=999;
  if(i==-1) i=999;
  if(e==-1) e=999;
  
  let ogWordNum = math.min(a,o,u,i,e);
  let preVowel = ogWord.slice(0, ogWordNum);
  return(ogWord.slice(ogWordNum) + preVowel + "ay");
}

console.log(pig("hello"));