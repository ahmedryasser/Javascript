/*
Name: Ahmed Najiub
URL: https://codepen.io/ahmedryasser/pen/KKKOgjL
*/
function numberMatrix(str: string): number[][] {
  let m = [];
  let rows = str.split(/\n/);
  for (let i = 0; i < rows.length; i++) {
    m[i] = [];
    let cols = rows[i].split(/\s+/);
    for (let j = 0; j < cols.length; j++) {
      m[i][j] = Number(cols[j]);
    }
  }
  return m;
}
function matrixMult(x: number[][], y: number[][] ): number[][]{
  let xRows = x.length;
  let xCols = x[0].length;
  let yRows = y.length;
  let yCols = y[0].length;
  let z = Array(xRows);
  let total=0;
  for (let i = 0; i < xRows; i++) {
    z[i]= Array(yCols);
    for (let j = 0; j < yCols; j++) {    
      z[i][j]=0;
      for (let k = 0; k < xCols; k++){
        z[i][j] += x[i][k] * y[k][j];
      }      
    }
  }
  return z;
}
function displayMatrix(m: number[][], widget: object): void{
  widget.html("<br>");
  for (let i = 0; i<m.length;i++){
    widget.append(m[i] +"<br>")
  }
}
$("#goButton").click(() => {
  let input1 = $("#xInput").val();
  let input2 = $("#yInput").val();
  let mat1 = numberMatrix(input1);
  let mat2 = numberMatrix(input2);
  let c = matrixMult(mat1, mat2);
  displayMatrix(c, $("#out"));
});