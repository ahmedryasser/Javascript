/*
Name: Ahmed Najiub
URL: https://codepen.io/ahmedryasser/pen/zYYMaJv?editors=0010
*/
function chessboard(rows:number): string {
  let str="";
  for (let i = 1; i<=rows;i++){
    for(let j = 1; j<=rows;j++){
      if (((i%2 !=0) && (j%2 !=0)) || ((i%2 ==0) && (j%2== 0))){
        str += " x ";
      }
      else{
        str += " o ";
      } 
    }
    str+= "<br>";
  }
  return str; 
}

$("#goButton").click(() => {
  let num = Number($("#rowsInput").val());
  let output = chessboard(num);
  if (num <= 0) {
    $("#out").html("Invalid");
  } 
  else {
    $("#out").html(output);
  }
});