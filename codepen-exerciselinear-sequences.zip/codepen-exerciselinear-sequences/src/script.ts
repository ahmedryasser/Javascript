/*
Name: Ahmed Najiub
URL: https://codepen.io/ahmedryasser/pen/WNNzzqW?editors=0011
*/
function numberArray(str: string): number[] {
  let numArray = str.split(/\s+/);
  let i = 0;
  while (i < numArray.length) {
    numArray[i] = Number(numArray[i]);
    i++;
  } 
  return numArray;
}
function isLinear(v: number[]): boolean{
  if (v.length<2){
    return false;
  }
  let seq = v[0];
  let increment = v[1]-v[0];
  let count=1;
  for (let i = 1; i<=v.length;i++){
    if ((v[i] - seq) == increment){
      count++;
      if (count == v.length){
        return true;
      }
    }
    else{
      return false;
    }
    seq = v[i];
  }
}
$("#goButton").click(() => {
  let num = numberArray($("#listInput").val());
  let output = isLinear(num);
  if (output){
    $("#out").html("The sequence is linear with an increment of " + (num[1]-num[0])); 
  }
  else{
    $("#out").html("The sequence is not linear");
  }
  
});

console.log("isLinear([]) == " + isLinear([]));                              // A: 0
console.log("isLinear([3]) == " + isLinear([3]));                            // A: 0
console.log("isLinear([3,6,9,12,15,18]) == " + isLinear([3,6,9,12,15,18]));  // A: 1
console.log("isLinear([3,6,9,12,16,19]) == " + isLinear([3,6,9,12,16,19]));  // A: 0
console.log("isLinear([4,8,12,16,20]) == " + isLinear([4,8,12,16,20]));      // A: 1
console.log("isLinear([4,8,9,13,17]) == " + isLinear([4,8,9,13,17]));        // A: 0
console.log("isLinear([5,7,9,11,13]) == " + isLinear([5,7,9,11,13]));        // A: 1
console.log("isLinear([10,20,30,39]) == " + isLinear([10,20,30,39]));        // A: 0
console.log("isLinear([10,2187]) == " + isLinear([10,2187]));                // A: 1
