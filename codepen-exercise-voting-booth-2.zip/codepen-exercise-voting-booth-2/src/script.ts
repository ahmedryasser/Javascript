function update() {
  $(".tally").css("backgroundColor", "darkblue");
  let candidate = $("#candidate").val();
  total++;
  switch (candidate) {
    case "w":
      warren++;
      break;
    case "b":
      biden++;
      break;
    case "s":
      sanders++;
      break;
    case "h":
      harris++;
      break;
    case "o":
      other++;
      break;
    default:
      total--;
  }
  $("#total").html("<strong>Total votes: " + total + "</strong>");
  $("#warren").html((100 * warren / total).toFixed(1) + "%");
  $("#biden").html((100 * biden / total).toFixed(1) + "%");
  $("#sanders").html((100 * sanders / total).toFixed(1) + "%");
  $("#harris").html((100 * harris / total).toFixed(1) + "%");
  $("#other").html((100 * other / total).toFixed(1) + "%");
  let max = Math.max(warren, biden, sanders, harris, other);
  if (max == warren) {
    $("#warren").css("backgroundColor", "red");
  } 
  else if (max == biden) {
    $("#biden").css("backgroundColor", "red");    
  } 
  else if (max == sanders) {
     $("#sanders").css("backgroundColor", "red");
  } 
  else if (max == harris) {
    $("#harris").css("backgroundColor", "red");
  } 
  else {
    $("#other").css("backgroundColor", "redd");
  }
}
let total = 0;
let warren = 0;
let biden = 0;
let sanders = 0;
let harris = 0;
let other = 0;

$("#vote").click(update);
  