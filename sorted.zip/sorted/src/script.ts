function numberArray(str: string): number[] {
  let numArray = str.split(/\s+/);
  let i = 0;
  while (i < numArray.length) {
    numArray[i] = Number(numArray[i]);
    i++;
  } 
  return numArray;
}

$("#go").click(() => {
  let numArray = numberArray($("#numbers").val());
  $("#out").html(numArray);
  if (isSorted(numArray)) {
    $("#out").html("<h1>Sorted!</h1>");
  } else {
    $("#out").html("<h1>Not Sorted, Loser!</h1>");   
  }
});

function isSorted(v: number[]): boolean {
  let i = 0;
  while (i < v.length - 1) {
    // console.log("v[" + i + "] = " + v[i]);
    // console.log("v[" + Number(i + 1) + "] = " + v[i + 1]);
    if (v[i] > v[i + 1]) {
      return false;
    }
    i++;
  }
  return true;
}

// let x = [3, 8,10, 12, 17, 26];
// if (isSorted(x)) {
//   console.log("The array is sorted.");
// } else {
//   console.log("The array is not sorted.");
// }