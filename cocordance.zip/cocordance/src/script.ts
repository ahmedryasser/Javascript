// let fruitCount = {
//   'apple':4,
//   'orange': 8,
//   'banana':1
// };
// fruitCount.orange=12;
// fruitCount.banana++;
// fruitCount['kiwi']=1;
// console.log(fruitCount);
$("#process").click(() => {
  let text = $("#manuscript").val();
  let words = text.split();
  let count = {};
  for (let i=0;i<words.length;i++){
    let word = words[i].toUpperCase();
    word =word.replace(",", " ");
    word =word.replace(".", " ");
    word =word.replace(";", " ");
    word =word.replace(":", " ");
    word =word.replace("?", " ");
    word =word.replace("!", " ");
    if (count[word]== undefined){
      count[word] = 1;
    }
    else{
      count[word]++;
    }
  }
  console.log(count);
  $("#out").html(count);
  //$("#out").html(words.join("<br/>"));
});
