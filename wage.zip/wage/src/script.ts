
function wages(hours: number, rate: number):number{
  if (hours>40){
    let overWage = (((hours-40)*rate*1.5)+ 40*rate);
    return overWage;
  }
  else{
    return hours*rate;
  }
}
console.log("The wage is " + wages(50, 10));