console.log(typeof 0);
let x=25;
console.log(Math.sqrt(x));
x=100;
console.log(Math.sqrt(x));
