let person = {
  name: "john",
  talent: "guitar",
  living: false,
  nationality: "british"
};
let j = {
  name: "john",
  talent: "guitar",
  living: false,
  nationality: "british"
};
let p = {
  name: "paul",
  talent: "bass",
  living: true,
  nationality: "british"
};
let g = {
  name: "george",
  talent: "Lead guitar",
  living: true,
  nationality: "british"
};
let r = {
  name: "ringo",
  talent: "drum",
  living: true,
  nationality: "british"
};

let beatle = [j, p, g, r];
console.log(person.name);
console.log(person["nationality"]);
console.log(Object.keys(person));
console.log(Object.values(person));