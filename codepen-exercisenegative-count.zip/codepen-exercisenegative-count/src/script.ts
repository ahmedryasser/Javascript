/*
Name: Ahmed Najiub
URL: https://codepen.io/ahmedryasser/pen/JjjypBr?editors=0010
*/
function numberArray(str: string): number[] {
  let numArray = str.split(/\s+/);
  let i = 0;
  while (i < numArray.length) {
    numArray[i] = Number(numArray[i]);
    i++;
  } 
  return numArray;
}
function negativeCount(v: number[]): number{
  let i=0;
  let neg = 0;
  while(i<=v.length){
    if (v[i]<0){
      neg++;
    }
    i++;
  }
  return neg;
}
$("#goButton").click (() => {
  num=$("#listInput").val();
  let output = negativeCount(numberArray(num));
  $("#out").html(output); 
  });


// console.log("negativeCount([]) == " + negativeCount([]));                                     // A: 0
// console.log("negativeCount([42]) == " + negativeCount([42]));                                 // A: 0
// console.log("negativeCount([-43]) == " + negativeCount([-43]));                               // A: 1
// console.log("negativeCount([1, 2, 3]) == " + negativeCount([1, 2, 3]));                       // A: 0
// console.log("negativeCount([-4, -6, -8, 10]) == " + negativeCount([-4, -6, -8, 10]));         // A: 3
// console.log("negativeCount([-2, 8, 5, 6, -4, 6]) == " + negativeCount([-2, 8, 5, 6, -4, 6])); // A: 2
// console.log("negativeCount([-2, 0, 2]) == " + negativeCount([-2, 0, 2]));                     // A: 1
// console.log("negativeCount([-5, -3, -3, -5]) == " + negativeCount([-5, -3, -3, -5]));         // A: 4
