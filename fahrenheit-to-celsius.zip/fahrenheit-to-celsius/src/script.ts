/*
    Name: Ahmed Najiub
    URL: https://codepen.io/ahmedryasser/pen/aboEwRz?editors=0012
*/
function celsius(fahrenheit: number): number{
  return ((fahrenheit-32)*(5/9));
}
function displayCelsius(fahrenheit:number):void {
  console.log(( fahrenheit + " degrees fahrenheit is " + celsius(fahrenheit).toFixed(1) + " degrees celsius "));
}


// Test code--do not change
console.log("celsius(32) => ", celsius(32));     // should print 0.0
console.log("celsius(212) => ", celsius(212));   // should print 100.0
console.log("celsius(73.5) => ", celsius(73.5)); // should print 23.055555555555557
console.log("celsius(-46) => ", celsius(-46));   // should print -43.333333333333336
console.log("celsius(0) => ", celsius(0));       // should print -17.77777777777778

displayCelsius(70.5);
/* Should display

70.5 degrees Fahrenheit is 21.4 degrees Celsius.

*/

displayCelsius(-46);
/* Should display

-46 degrees Fahrenheit is -43.3 degrees Celsius.

*/
