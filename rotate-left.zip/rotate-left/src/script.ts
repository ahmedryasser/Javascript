function numberArray(str: string): number[] {
  let numArray = str.split(/\s+/);
  let i = 0;
  while (i < numArray.length) {
    numArray[i] = Number(numArray[i]);
    i++;
  } 
  return numArray;
}
function rotateLeft(v:number[]):number[]{
  let temp = v[0];
  for (let i=0;i<v.length;i++){
    v[i] = v[i+1];
  }
  v[v.length-1]= temp;
  return v;
}
$("#goButton").click(() => {
  let num = numberArray($("#input").val());
  let output = rotateLeft(num)
  $("#out").html(output);
});
