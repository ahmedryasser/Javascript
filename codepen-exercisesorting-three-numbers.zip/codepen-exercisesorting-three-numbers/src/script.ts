/*
    Name: Ahmed Najiub
    URL: https://codepen.io/ahmedryasser/pen/aboPWRQ?editors=0011
*/

function inOrder (a: number, b: number, c:number): number[]{
  if (a > b ){
    if (b > c){
      return [c, b, a];

    }
    else if (a>c){
      return [b, c, a];
    }
    else {
      return [b, a, c];
    }
  } 
  else {
    if (a>c){
      return [c, a, b];
    }
    else if (b>c){
      return[a, c, b];
    }
    else {
      return[a, b, c];
    }
  }
    
    
  

}
// Test code--do not change

console.log("inOrder(10, 20, 30) => ", inOrder(10, 20, 30));   // should print [10, 20, 30] 
console.log("inOrder(20, 10, 30) => ", inOrder(50, 40, 60));   // should print [40, 50, 60]
console.log("inOrder(80, 90, 70) => ", inOrder(80, 90, 70));   // should print [70, 80, 90]
console.log("inOrder(33, 22, 11) => ", inOrder(33, 22, 11));   // should print [11, 22, 33]
console.log("inOrder(44, 66, 55) => ", inOrder(44, 66, 55));   // should print [44, 55, 66]
console.log("inOrder(99, 77, 88) => ", inOrder(99, 77, 88));   // should print [77, 88, 99]
console.log("inOrder(12, 18, 12) => ", inOrder(12, 18, 12));   // should print [12, 12, 18]
console.log("inOrder(18, 18, 12) => ", inOrder(18, 18, 12));   // should print [12, 18, 18]