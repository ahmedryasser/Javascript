/*
Name: Ahmed Najiub
URL: https://codepen.io/ahmedryasser/pen/abbrzGJ?editors=0010
*/
function numberMatrix(str: string): number[][] {
  let m = [];
  let rows = str.split(/\n/);
  for (let i = 0; i < rows.length; i++) {
    m[i] = [];
    let cols = rows[i].split(/\s+/);
    for (let j = 0; j < cols.length; j++) {
      m[i][j] = Number(cols[j]);
    }
  }
  return m;
}
function scalarMult(x: number, y: number[][] ): number[][]{
  let z=[];
    for (let i = 0; i < y.length; i++) {
      z[i]= [];
      for (let j = 0; j < y[i].length; j++) {
        z[i][j] = (y[i][j])*x;
      }
    }
  return z;
}
function displayMatrix(m: number[][], widget: object): void{
  widget.html("<br>");
  for (let i = 0; i<m.length;i++){
    widget.append(m[i] +"<br>")
  }
}
$("#goButton").click(() => {
  let input = $("#scalarInput").val();
  let mat = numberMatrix($("#matrixInput").val());
  let c = scalarMult(input,mat);
  displayMatrix(c, $("#out"));
  
});