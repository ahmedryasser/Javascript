/*
    Name: Ahmed Najiub
    URL: https://codepen.io/ahmedryasser/pen/mdboJma?editors=0010
*/
function lastNameFirst(name: string): string {
  if (name.includes(' ')){
    let spaceIndex = name.indexOf(' ');
  }
  else{
    return name;
  }
  
  let last = name.slice(spaceIndex);
  let first = name.slice(0, spaceIndex);
  return (last + ", " + first);
}


// Test code--do not change

console.log("lastNameFirst(\"Stan Warford\") => " + lastNameFirst("Stan Warford"));
    // should print Warford, Stan
console.log("lastNameFirst(\"Susan Helm\") => " + lastNameFirst("Susan Helm"));  
    // should print Helm, Susan
console.log("lastNameFirst(\"Jennifer Lawrence\") => " + lastNameFirst("Jennifer Lawrence"));  
    // should print Lawrence, Jennifer
console.log("lastNameFirst(\"Jesse Jackson\") => " + lastNameFirst("Jesse Jackson"));  
    // should print Jackson, Jesse
console.log("lastNameFirst(\"Bea Arthur\") => " + lastNameFirst("Bea Arthur"));
    // should print Arthur, Bea
console.log("lastNameFirst(\"Rihanna\") => " + lastNameFirst("Rihanna"));
    // should print Rihanna
console.log("lastNameFirst(\"Milli Vanilli\") => " + lastNameFirst("Milli Vanilli"));
    // should print Vanilli, Milli
