/*
function double(x: number):number {
  return 2*x;
}
*/
function area(width:number, height:number):number{
  return width*height;
}
function perimeter(width:number, height:number):number{
  return (2*width)+(2*height)
 } 
/*

console.log(double(3));
console.log( "The perimeter is " + area(5,6));
console.log("The perimeter is " + perimeter(5,6));
*/
function dispalayRectangle(width: number, height: number): void {
  console.log("This is a rectangle.");
  console.log("width: " + width.toFixed());
  console.log("height: " + height.toFixed());
  console.log("area: " + area(width, height).toFixed());
  console.log("perimeter: " + perimeter(width, height).toFixed());
}
  displayRectangle(5, 6);