function grade(mark:number):string{
  if (mark>=90){
    return "A";
  }
  else if (mark<90 && mark>=80){
    return "B";
  }
  else if (mark<80 && mark>=70){
    return "C";
  }
  else if (mark<70 && mark>=60){
    return "D";
  }
   else if (mark<60){
    return "F";
  }  
}
console.log(grade(88));