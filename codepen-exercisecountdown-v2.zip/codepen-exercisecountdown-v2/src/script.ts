/*
    Name: Ahmed Najiub
    URL: https://codepen.io/ahmedryasser/pen/bGGeEwB?editors=1010
*/
countdown.n=0;
function countdown(){
  (countdown.n)++
  $("#out").html("");
  let i = Number($("#numInput").val());
  let r = 255;
  let g = 255;
  let b = 0;
  $("#out").append(i-countdown.n);
  $("#out").css("color", "rgb(" + r + "," + g/(i-countdown.n) + "," + b + ")");
  if (countdown.n == i) {
    clearInterval(countdown.timer);
    $("#out").append(" </br> BOOOOM!");
  }   

}
$("#goButton").click(() => {
  countdown.timer = setInterval(countdown, 500);
});


