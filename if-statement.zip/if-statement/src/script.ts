function pluralize (word: string, amount:number): string{
  if (amount != 1){
    word = word + "s";
    return word;
  }
  else{
    return word;
  }
}
function passFail(score: number):string{
  if (score >= 60){
    return "pass";
  }
  else{
    return "fail";
  }

}
console.log(passFail(59));