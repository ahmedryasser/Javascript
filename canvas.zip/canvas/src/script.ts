
function drawTriangle() {
  let canvas = document.getElementById("myCanvas");
  let c = canvas.getContext("2d");
  let dpr = window.devicePixelRatio;
  let rect = canvas.getBoundingClientRect();
  canvas.width = rect.width * dpr;
  canvas.height = rect.height * dpr;
  c.scale(dpr, dpr);
  // changable code begins here
  
  let rows = Number($("#rows").val());
  const w = 20;
  const h = 20;
  const start_x = 40;
  const start_y = 40;
  const gap = 10;
  c.fillStyle = "black";
  for (let i = 0; i<rows; i++){
    for (let j = 0; j<rows; j++){
      c.fillRect(start_x + j*(w+gap), start_y + i*(h+gap), w, h);
    }
  }
  // c.fillRect(start_x, start_y, w, h);
}

$("#go").click(drawTriangle);