function city(phoneNumber: string): string{
  let areacode = phoneNumber.slice(1, 4);
  switch (areacode){
    case '301':
      c=  "LA";
      break;
    case '245':
      c= "San Diego";
      break;
    case '485':
      c= "Irvine";
      break;
    case '394':
      c= "San Fransisco";
      break;
    case '949':
      c= "New york";
      break;
    default:   
      c= "unknown"
  }
  return c;
}

console.log(city('(301)57904549'))
console.log(city('(245)52904949'))
console.log(city('(485)35703949'))
console.log(city('(394)53904949'))
console.log(city('(949)90934249'))