/*
Name: Ahmed Najiub
URL: https://codepen.io/ahmedryasser/pen/BaaZQVB?editors=1011
*/
function isPrime(n: number):boolean{
  let i=2;
  while(i<=n/2){
    if (n%i==0){
      return false;
    }
    i++;
  }
  return true;
}

$("#goButton").click(() => {
  let num=$("#decimalInput").val();
  let pri = isPrime(num);
  if (pri){
    $("#out").html(num+" is a prime number");}
  else{
    $("#out").html(num+" is not a prime number");
  }
});

// console.log("isPrime(13) == " + isPrime(13));       // A: 1
// console.log("isPrime(15) == " + isPrime(15));       // A: 0
// console.log("isPrime(137) == " + isPrime(137));     // A: 1
// console.log("isPrime(1493) == " + isPrime(1493));   // A: 1
// console.log("isPrime(1497) == " + isPrime(1497));   // A: 0
// console.log("isPrime(18649) == " + isPrime(18649)); // A: 0
// console.log("isPrime(18653) == " + isPrime(18653)); // A: 0
// console.log("isPrime(18659) == " + isPrime(18659)); // A: 0
// console.log("isPrime(18661) == " + isPrime(18661)); // A: 1
// console.log("isPrime(1) == " + isPrime(1));         // A: 1
