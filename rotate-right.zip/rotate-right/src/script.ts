function numberArray(str: string): number[] {
  let numArray = str.split(/\s+/);
  let i = 0;
  while (i < numArray.length) {
    numArray[i] = Number(numArray[i]);
    i++;
  } 
  return numArray;
}
function rotateRight(v:number[]){
  let len = v.length;
  let temp = v[len-1]
  for(let i=1;i<=len-1;i++){
    v[len - i]=v[len-i-1]
  }
  v[0]=temp;
  return v;
}
$("#goButton").click(() => {
  let num = numberArray($("#input").val());
  let output = rotateRight(num)
  $("#out").html(output);
});
