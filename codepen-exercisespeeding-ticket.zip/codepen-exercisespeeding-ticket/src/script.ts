/*
    Name: Ahmed Najiub
    URL: https://codepen.io/ahmedryasser/pen/mdbjmyR?editors=0010 
*/
function fine(speed: number):number {
  if (speed <= 45){ 
    return 0;
      }
  else if(speed > 65){
    return (speed-65)*20 + 250;
  }
  else if (speed > 55){
    return ((speed-55)*15) + 100;
  }
  else {
    return (speed-45)*10;
  }

  
}



// Test code--do not change

console.log("fine(40) => ", fine(40)); // should print 0
console.log("fine(45) => ", fine(45)); // should print 0
console.log("fine(46) => ", fine(46)); // should print 10
console.log("fine(55) => ", fine(55)); // should print 100
console.log("fine(57) => ", fine(57)); // should print 130
console.log("fine(65) => ", fine(65)); // should print 250
console.log("fine(75) => ", fine(75)); // should print 450
