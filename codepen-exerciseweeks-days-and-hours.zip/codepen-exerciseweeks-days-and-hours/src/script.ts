/*
    Name: Ahmed Najiub
    URL: https://codepen.io/ahmedryasser/pen/wvwyxbp
*/

function weeksDaysHours(hours: number): number[]{
  let weeks = Math.floor(hours/168);
  let days = Math.floor((hours-(weeks*168))/24);
  let hours2 = (hours-((weeks*168)+(days*24)));
  return[weeks, days, hours2];
}

// Test code--do not change

console.log("weeksDaysHours(195) => ", weeksDaysHours(195)); // should print [1, 1, 3]
console.log("weeksDaysHours(500) => ", weeksDaysHours(500)); // should print [2, 6, 20]
console.log("weeksDaysHours(350) => ", weeksDaysHours(350)); // should print [2, 0, 14]
console.log("weeksDaysHours(65) => ", weeksDaysHours(65));   // should print [0, 2, 17]
console.log("weeksDaysHours(222) => ", weeksDaysHours(222)); // should print [1, 2, 6]

