/*
    Name: Ahmed Najiub
    URL: https://codepen.io/ahmedryasser/pen/WNNPazd?editors=1010
*/

function chessBoard() {
  let canvas = document.getElementById("c");
  let c = canvas.getContext("2d");
  let dpr = window.devicePixelRatio;
  let rect = canvas.getBoundingClientRect();
  canvas.width = rect.width * dpr;
  canvas.height = rect.height * dpr;
  c.scale(dpr, dpr);
  // changable code begins here
  
  let rows = Number($("#rowsInput").val());
  const w = 20;
  const h = 20;
  const start_x = 40;
  const start_y = 40;
  const gap = 10;
  
  for (let i = 1; i<=rows; i++){
    for (let j = 1; j<=rows; j++){
      if (((i%2 !=0) && (j%2 !=0)) || ((i%2 ==0) && (j%2== 0))){
        c.fillStyle = "red";
        c.fillRect(start_x + j*w, start_y + i*h, w, h);
      }
      else{
        c.fillStyle = "blue";
        c.fillRect(start_x + j*w, start_y + i*h, w, h);        
      }
    }
  }
  // c.fillRect(start_x, start_y, w, h);
}

$("#goButton").click(chessBoard);