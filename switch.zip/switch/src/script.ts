function quiz(answer: string): string{
  response = "";
  switch (answer){
    case "a":
      response = "She has a plan for that. ";
      break;
    case "b":
      response = "Again? ";
      break;
    case "c":
      response = "Show me the money ";
      break;
    case "d":
      response = "It's possible ";
      break;
    default:
      response = "Not a valid choice ";
      break;
            
  }
}