 function waterState(temp:number): string{
   if (temp<=32){
     return "ice";
   }
   else if (temp<212){
     return "liquid";
   }
   else{
     return "steam";
   }
 }

console.log("30 => " + waterState(30))
console.log("40 => " + waterState(40))
console.log("211 => " + waterState(211))
console.log("212 => " + waterState(212))
console.log("-8 => " + waterState(-8))
console.log("62 => " + waterState(62))