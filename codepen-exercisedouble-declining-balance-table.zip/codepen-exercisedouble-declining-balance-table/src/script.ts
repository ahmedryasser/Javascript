/*
    Name: Ahmed Najiub
    URL: https://codepen.io/ahmedryasser/pen/oNNBpMM?editors=1010
*/


function ddb(cost:number, n:number): number{
  $("#out").html(" ");
  let i =1;
  $("#out").html("<table id= table><tr><th> Cost </th><th> Life </th> </tr><tr id=row1> </tr>")
  $("#table").append("<tr><td>" + 0 + "</td>" + "<td>" + cost + "</td>" "</tr>");
  while(n>=i ){

    cost = cost-((2/n)*cost);  
    $("#table").append("<tr><td>" + i + "</td>" + "<td>" + cost + "</td><tr>");    

    i++;
  }
   $("#table").append("</table>");   
}
$("#goButton").click(() => {
  ddb.cost = Number($("#costInput").val());;
  ddb.n = Number($("#lifeInput").val());;
  $("#out").append(ddb(ddb.cost, ddb.n));
}
);
