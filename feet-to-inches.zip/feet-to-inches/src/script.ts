/*
    Name: Ahmed Najiub
    URL: https://codepen.io/ahmedryasser/pen/yLBpbzX?editors=0012
*/

function meters(feet: number, inches: number): number {
  let numInches = (feet*12) + inches;
  return numInches*0.0254;

}
function displayMeters(feet: number, inches: number): void {
  console.log("Feet: " + feet);
  console.log("Inches: " + inches);
  console.log("Meters: " + meters(feet, inches).toFixed(2));
}

// Test code--do not change
console.log("meters(0, 10) => ", meters(0, 10)); // should print 0.254
console.log("meters(2, 3) => ", meters(2, 3));   // should print 0.6858
console.log("meters(6, 11) => ", meters(6, 11)); // should print 2.1082
console.log("meters(5, 2) => ", meters(5, 2));   // should print 1.5748
console.log("meters(4, 8) => ", meters(4, 8));   // should print 1.4223999999999999

displayMeters(5, 10);
/* Should display

Feet: 5
Inches: 10
Meters: 1.78

*/

displayMeters(4, 8);
/* Should display

Feet: 4
Inches: 8
Meters: 1.42

*/