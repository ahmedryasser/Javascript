function verLongLeap(year: number): boolean{
  if (year%4==0){
    if (year%100==0){
      if (year%400==0){
        return true;
      }
      else{
        return false;
      }
    }
    else{
      return true;
    }
  }
  else{
    return false;
  }
}
function leap(year: number): boolean{
  return(year%4==0) && ((year%100 != 0) || (year % 400 == 0))
}


console.log("2016 => " + leap(2016));
console.log("2001 => " + leap(2001));
console.log("2020 => " + leap(2020));
console.log("2000 => " + leap(2000));
console.log("2100 => " + leap(2100));