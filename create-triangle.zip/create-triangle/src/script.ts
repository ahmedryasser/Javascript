$("goButton").click(() => {
  let num= $("input").val;
  for(let i=0;i<num;i++){
    for(let v=0;v<num;v++){
      $("out").append("*");
    }
  $("out").append(" ");
  }
});