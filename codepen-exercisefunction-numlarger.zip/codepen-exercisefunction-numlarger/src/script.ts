/*
Name: Ahmed Najiub
URL: https://codepen.io/ahmedryasser/pen/OJPJEZE?editors=0010
*/
function numberMatrix(str: string): number[][] {
  let m = [];
  let rows = str.split(/\n/);
  for (let i = 0; i < rows.length; i++) {
    m[i] = [];
    let cols = rows[i].split(/\s+/);
    for (let j = 0; j < cols.length; j++) {
      m[i][j] = Number(cols[j]);
    }
  }
  return m;
}
function numLarger(x: number[][], y: number[][] ): number{
  let z=0;
    for (let i = 0; i < y.length; i++) {
      for (let j = 0; j < y[i].length; j++) {
        if(x[i][j]>y[i][j]){
          z++;
        }
      }
    }
  return z;
}

$("#goButton").click(() => {
  let xInput = $("#xInput").val();
  let yInput = $("#yInput").val();
  let xMat = numberMatrix(xInput);
  let yMat = numberMatrix(yInput);  
  let c = numLarger(xMat,yMat);
  $("#out").html(c); 
});