/*
Name: Ahmed Najiub
URL: https://codepen.io/ahmedryasser/pen/BaaZmxp
*/
function fibSeq(n:number):number{
  if (n==1){return 0;}
  let i=0;
  let num1 = 0;
  let num2 = 1;
  let num3;
  let seq = [" 0 " + " 1 "];
  while(i<n-2){
    num3 = num1+num2;
    seq += String(num3) + " ";
    num1 = num2;
    num2 = num3;
    i++;
  }
  return seq;
}

$("#goButton").click (() => {
  num=$("#numInput").val();
  let output = fibSeq(num);
  if (num>0){
    $("#out").html(output); 
  } 
  else{
    $("#out").html("Input is invalid");
  }
});