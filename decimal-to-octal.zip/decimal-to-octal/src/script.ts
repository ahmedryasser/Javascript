function dec2oct(dec:number):string{
  let octStr="";
  while (dec>0){
    let sum = dec%8;
    octStr = sum + octStr;
    dec = Math.floor(dec/8);
  }
  return octStr;
}
$("#button").click( () => {
  let num = $("#input").val();
  $("#out").html(dec2oct(num));
}