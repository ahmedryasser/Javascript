function matrixAdd(x: number[][], y: number[][]): number[][]{
  let z = [];
  for (let i=0; i<x.length;i++){
    z[i]=[];
    for (let j=0; j<x[i].length;j++){
      z[i][j] = x[i][j] + y[i][j];
    }
  }
  return z;
}
function displayMatrix(m: number[][], widget: object): void{
  widget.html("<br>");
  for (let i = 0; i<m.length;i++){
    widget.append(m[i] +"<br>")
  }
  // widget.html("<table>");
  // for (let i=0; i < m.length; i++){
  //   widget.append("<tr>");
  //   for (let j=0; j < m[i].length; j++){
  //     widget.append("<td>");
  //     widget.append(m[i][j]);
  //     widget.append("</td>");
  //   }
  //   widget.append("</tr>");
  // }
  // widget.append("</table>");
}
$("#go").click(() => {
  let a = numberMatrix($("#a").val());
  let b = numberMatrix($("#b").val());
  let c = matrixAdd(a,b);
  $("#out").html(c);
});