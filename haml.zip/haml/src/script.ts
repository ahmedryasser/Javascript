$("#calcButton").click(() => {
  let width = Number($("#widthInput").val());
  let height = Number($("#heightInput").val());
  let area = width*height;
  let perimeter = 2*width + 2*height;
  $("#out").html("Area: " + area);
  $("#out2").html("Perimeter: " + perimeter);
  $("#rect").css("width", width);
  $("#rect").css("height", height);
  $("#rect").css("visibility", "visible");
  
});
