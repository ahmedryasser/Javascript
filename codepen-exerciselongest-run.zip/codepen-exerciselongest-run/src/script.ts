/*
Name: Ahmed Najiub
URL: https://codepen.io/ahmedryasser/pen/mddLRLM?editors=0010
*/
function numberArray(str: string): number[] {
  let numArray = str.split(/\s+/);
  let i = 0;
  while (i < numArray.length) {
    numArray[i] = Number(numArray[i]);
    i++;
  } 
  return numArray;
}

function longestRun(v: number[]): number{
  let currentRun=1;
  // let repNum=v[0];
  let runMax=1;
  let run=v[0];
  if (v.length < 2){
    return v.length;
  }
  
  for (let i=1; i<v.length; i++){
    // currentRun = (v[i] == v[currentRun]? currentRun++:0);
    if (v[i] == run){
      currentRun++;
      
      if (currentRun> runMax){
        runMax = currentRun;
      }
    }
    else{
      currentRun = 1;
    }
    run = v[i];
    // runMax = (currentRun > runMax? currentRun:runMax);
  }
  return runMax;
}
$("#goButton").click(() => {
  let num = numberArray($("#listInput").val());
  let output = longestRun(num);
  $("#out").html(output);
});

// console.log("longestRun([]) == " + longestRun([]));                                                         // A: 0
// console.log("longestRun([8]) == " + longestRun([8]));                                                       // A: 1
// console.log("longestRun([8,3,4]) == " + longestRun([8,3,4]));                                               // A: 1
// console.log("longestRun([1,1,2,2,2,3,3]) == " + longestRun([1,1,2,2,2,3,3]));                               // A: 3
// console.log("longestRun([12,3,3,3,3,3,16,3,4,16,9,4,4]) == " + longestRun([12,3,3,3,3,3,16,3,4,16,9,4,4])); // A: 5
// console.log("longestRun([12,3,3,16,3,4,16,9,4,4,4]) == " + longestRun([12,3,3,3,3,3,16,3,4,16,9,4,4]));     // A: 3
